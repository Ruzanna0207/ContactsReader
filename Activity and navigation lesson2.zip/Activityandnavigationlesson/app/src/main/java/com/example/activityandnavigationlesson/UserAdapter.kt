package com.example.activityandnavigationlesson

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.activityandnavigationlesson.databinding.ForRecyclerviewBinding

class UserAdapter : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    var userList: List<String> = emptyList()

    //----------------------------------------------------------------------------------------------
    class UserViewHolder(val binding: ForRecyclerviewBinding) :
        RecyclerView.ViewHolder(binding.root)

    //==============================================================================================
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val binding =
            ForRecyclerviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return UserViewHolder(binding)
    }

    //----------------------------------------------------------------------------------------------
    override fun getItemCount(): Int = userList.size

    //----------------------------------------------------------------------------------------------
    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = userList[position]
        with(holder.binding) {
            userEditText.hint = user
        }
    }
}
