package com.example.activityandnavigationlesson

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.activityandnavigationlesson.databinding.ActivityCreateContactBinding
import com.example.activityandnavigationlesson.databinding.CustomDialogBinding

class CreateContactActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateContactBinding
    private val adapter = UserAdapter() //создана ссылка на адаптер

    private val listUsers = listOf(
        "Ф.И.О.",
        "Номер телефона",
        "Год рождения",
        "Компания / Должность",
        "Никнейм",
        "Telegram",
        "Skype",
        "Web-Site"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateContactBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerViewForContacts.adapter =
            adapter // присваиваем для recyclerView свой адаптер
        adapter.userList = listUsers // присваиваем значение списку
        adapter.notifyDataSetChanged() //внесение изменений для адаптера

        binding.itBlockedText.visibility =
            if (binding.blackList.isChecked) View.VISIBLE else View.GONE
        binding.blackList.setOnCheckedChangeListener { _, isChecked -> //при нажатии на галочку в элементе blacklist элемент itBlockedText будет показан, иначе - нет
            binding.itBlockedText.visibility = if (isChecked) View.VISIBLE else View.GONE
        }

        setSupportActionBar(binding.myToolbar) // toolbar
        binding.myToolbar.setNavigationOnClickListener {  // alert dialog
            AlertDialog.Builder(this)
                .setTitle("Вы уверены что хотите выйти?")
                .setPositiveButton("Да") { dialog, which -> finish() }
                .setNegativeButton("Нет") { dialog, _ -> dialog.dismiss() }
                .setCancelable(false)
                .show()
        }

        binding.buttonEnter.setOnClickListener { //при нажатии на кнопку enter выводится "Контакт добавлен"
            Toast.makeText(this, "Контакт добавлен", Toast.LENGTH_SHORT).show()
        }
    }

//__________________________________________________________________________________________________


    override fun onCreateOptionsMenu(menu: Menu?): Boolean { //создание меню в toolbar
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {    // если кнопка в меню (справа) будет нажата выполнится условие для alert dialog
        val view = CustomDialogBinding.inflate(layoutInflater)
        val alertDialog =
            android.app.AlertDialog.Builder(this).setView(view.root).create()  //custom dialog

        view.yesBtn.setOnClickListener {
            val intent = Intent(this, RedactContact::class.java)
            startActivity(intent)
        }

        view.noBtn.setOnClickListener {
            alertDialog.dismiss()
        }

        when (item.itemId) {
            R.id.addContactMenu -> {
                alertDialog.show()
            }
        }
        return false
    }
}



