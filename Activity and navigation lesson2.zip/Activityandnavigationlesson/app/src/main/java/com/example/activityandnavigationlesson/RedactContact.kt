package com.example.activityandnavigationlesson

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.activityandnavigationlesson.databinding.RedactContactBinding

class RedactContact : AppCompatActivity() {  //ГЛАВНАЯ СТРАНИЦА
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bindingClass = RedactContactBinding.inflate(layoutInflater)
        setContentView(bindingClass.root)

        bindingClass.myButton2.setOnClickListener { //при нажатии на кнопку откроется след-ее активити
            startActivity(Intent(this, CreateContactActivity::class.java))
            this.finish() //функция завершает действие текущего активити и вернуться к нему кнопкаой назад будет невозможно
        }


    } //для данного активити так же указано в манифесте android:noHistory="true", что после первго перехода не позволяет вернуться к данному активити  второй раз
}